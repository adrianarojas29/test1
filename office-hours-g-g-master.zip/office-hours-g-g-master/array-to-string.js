/*
Crear una funcion que reciba como parametro un array y retorne una cadena
-> retorne quack! sneeze! boom!
*/
var arr = ["quack","sneeze","boom"];